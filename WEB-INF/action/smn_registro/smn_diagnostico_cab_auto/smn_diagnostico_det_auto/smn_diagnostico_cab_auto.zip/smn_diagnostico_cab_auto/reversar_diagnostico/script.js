search();
alertBox('El registro fue reversado de la base de datos', 'Continuar', null, null);

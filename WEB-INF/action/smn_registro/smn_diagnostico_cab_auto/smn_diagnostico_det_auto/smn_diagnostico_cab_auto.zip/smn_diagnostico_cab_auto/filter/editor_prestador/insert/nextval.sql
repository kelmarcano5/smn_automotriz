select ${seq:nextval@smn_automotriz.seq_smn_diagnostico_cab_auto} as id

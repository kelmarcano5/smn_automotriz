select	
	smn_automotriz.smn_diagnostico_cab_auto.*
from
	smn_automotriz.smn_diagnostico_cab_auto 
where
	smn_diagnostico_cab_auto_id = ${fld:id} 
	



delete from smn_automotriz.smn_diagnostico_cab_auto where smn_diagnostico_cab_auto_id = ${fld:id}
delete from smn_automotriz.smn_diagnostico_det_auto where smn_diagnostico_cab_auto_id = ${fld:id};

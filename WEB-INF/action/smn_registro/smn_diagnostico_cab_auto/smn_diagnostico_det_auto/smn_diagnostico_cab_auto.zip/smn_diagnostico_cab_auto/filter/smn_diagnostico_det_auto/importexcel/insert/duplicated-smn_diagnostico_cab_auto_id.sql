select
	smn_diagnostico_cab_auto_id	
from 
	smn_automotriz.smn_diagnostico_cab_auto
where
	smn_diagnostico_cab_auto_id = ${fld:smn_diagnostico_cab_auto_id}
	
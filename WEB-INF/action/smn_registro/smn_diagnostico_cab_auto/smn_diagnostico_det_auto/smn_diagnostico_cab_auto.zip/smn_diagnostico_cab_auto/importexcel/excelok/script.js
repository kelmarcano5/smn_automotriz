addNew();
alertBox ('${lbl:b_excel_ok}', '${lbl:b_continue_button}', null, 'setFocusOnForm("form1");');

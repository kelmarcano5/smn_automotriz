select ${seq:nextval@smn_base.seq_smn_mensajes} as id

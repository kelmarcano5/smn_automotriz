select ${seq:nextval@smn_base.seq_smn_respuestas} as id

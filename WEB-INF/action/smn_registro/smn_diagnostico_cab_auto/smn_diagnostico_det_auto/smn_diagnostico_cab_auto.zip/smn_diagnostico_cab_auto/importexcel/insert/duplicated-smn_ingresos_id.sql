select
	smn_ingresos_id	
from 
	smn_automotriz.smn_ingresos
where
	smn_ingresos_id = ${fld:smn_ingresos_id}
	
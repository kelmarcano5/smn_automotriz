search();
alertBox('El registro fue eliminado de la base de datos', 'Continuar', null, null);

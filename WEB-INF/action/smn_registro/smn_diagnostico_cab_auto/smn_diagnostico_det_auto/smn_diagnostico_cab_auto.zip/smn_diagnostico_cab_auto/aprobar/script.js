search();
alertBox('El registro fue aprobar en la base de datos', 'Continuar', null, null);

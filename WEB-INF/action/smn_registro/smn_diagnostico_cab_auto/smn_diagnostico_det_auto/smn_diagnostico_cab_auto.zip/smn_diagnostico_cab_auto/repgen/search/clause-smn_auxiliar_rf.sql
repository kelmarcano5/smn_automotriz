 and
 	smn_automotriz.smn_diagnostico_cab_auto.smn_auxiliar_rf=${fld:smn_auxiliar_rf}
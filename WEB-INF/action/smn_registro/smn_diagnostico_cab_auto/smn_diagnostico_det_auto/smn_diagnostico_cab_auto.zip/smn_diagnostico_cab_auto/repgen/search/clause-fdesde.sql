 and
 	${smn:schema}.${smn:table}.${smn:acronym}_fecha_registro>=${fld:fdesde}
 and
 	smn_automotriz.smn_diagnostico_cab_auto.smn_clase_auxiliar_rf=${fld:smn_clase_auxiliar_rf}
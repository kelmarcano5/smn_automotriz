 and
 	smn_automotriz.smn_diagnostico_cab_auto.smn_ingresos_id=${fld:smn_ingresos_id}